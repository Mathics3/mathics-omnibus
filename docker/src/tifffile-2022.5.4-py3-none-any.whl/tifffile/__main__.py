# tifffile/__main__.py

"""Tifffile package command line script."""

import sys

from .tifffile import main

sys.exit(main())
