#!/bin/sh

autoheader && autoconf
