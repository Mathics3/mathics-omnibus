class Password:

    types = {
        'value': str
    }

    def __init__(self):

        self.value = None  # str
