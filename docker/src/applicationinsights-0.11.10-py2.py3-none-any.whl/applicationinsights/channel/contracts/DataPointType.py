class DataPointType(object):
    """Data contract class for type DataPointType."""
    # Enumeration value measurement
    measurement = 0
    
    # Enumeration value aggregation
    aggregation = 1
    

