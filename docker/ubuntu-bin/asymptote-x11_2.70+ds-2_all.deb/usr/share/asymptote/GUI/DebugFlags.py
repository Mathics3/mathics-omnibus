#!/usr/bin/env python3

keepFiles = False
printFoutTranscript = False
printDeconstTranscript = False
forceRasterizationSVG = False
